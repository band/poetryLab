# Example package to learn about using Poetry

This package contains a Python program that outputs one line of text.

